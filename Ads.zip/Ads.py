import streamlit as st
import boto3
import json
import base64
import os
import random
import tempfile
from PIL import Image
import cv2
import numpy as np
from pydub import AudioSegment

# AWS Bedrock Configuration
# AWS_DEFAULT_REGION = "us-west-2"
# AWS_ACCESS_KEY_ID = "ASIAZJYILFAHX4VYUDMI"
# AWS_SECRET_ACCESS_KEY = "S0MpSql+E12Y59P4IseQiORxHBuHXvVxXN/71IAJ"
# AWS_SESSION_TOKEN = "IQoJb3JpZ2luX2VjEPv//////////wEaCXVzLWVhc3QtMSJIMEYCIQCTnzAn0/2c4pxpbQh/f9cy5/VP6V1xIYGXzlJ+FcMGFQIhAJZUcgMM8GCfLhtZaV0jwuvZq+6lsWwELGkome8QfoNeKqICCKT//////////wEQABoMNjM5NDMwNzY0NTU5IgzARAKjeX6zOa3jDLgq9gEQMG2i7m9bB2vFsl78IldO2ZfoD5Jw4MbplKpT+XDtDHbc6wf6zIQ6YanQU/N1ePlFSEh8SCPob0XJu4io5CYAGA/pwT/j0KG94z9Xpewm8y2T4OvfcmTZmc7apTeK7rxDyfq/Zigitey0BWEcjhsT2memakMF+SIbbrtcW72NG9weZd5WbWUOdtnO3RoLbNzwyK07P2WuTchGK9SMGdgdMLCpq3qoi+TQ4yveeIJ8gkVLpE+Trxsv88Mp4TAk6nKHequyXQNMx0Ku5cjd6IZxIs306eBzxXnErCMoI6XL3U6TgmP+HHYo2eOOac8CIuxHm0ViqPowz/+wugY6nAEz7ce+qbk2H4bIafQ3ntsCJw8o3kEygVIJ2kihhDaFg/R9m5uaS9fUBLzznLNDyUQmKSMRA0ewiHXbnFN2/bp11jKaYqpIbFIzI2Uv/Kp4c9kHiKORnX6rI2Xa85qXtmoeYPXD+Di/oDZGDqTOGwXpuE/2qhqklh9Cm+XnS4lcSoHzEGXttA6n0+vgVw69EOUVKEuYwxoYYlvVogk="


# Initialize Bedrock client
# bedrock = boto3.client(
#     service_name="bedrock-runtime",
#     aws_access_key_id=AWS_ACCESS_KEY_ID,
#     aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
#     aws_session_token=AWS_SESSION_TOKEN
# )

# Function to invoke LLaMA model
def invoke_llama(prompt):
    payload = {
        "prompt": prompt,
        "max_gen_len": 512,
        "temperature": 0.8,
        "top_p": 0.9
    }
    body = json.dumps(payload)
    response = bedrock.invoke_model(
        body=body,
        modelId="meta.llama3-8b-instruct-v1:0",
        accept="application/json",
        contentType="application/json"
    )
    response_body = json.loads(response['body'].read().decode('utf-8'))
    return response_body.get('generation', 'Error: No output from LLaMA model.').strip()

# Function to generate images using Stable Diffusion
def generate_ad_image(prompt):
    payload = {
        "prompt": prompt,
        "mode": "text-to-image",
        "aspect_ratio": "1:1",
        "output_format": "jpeg"
    }
    body = json.dumps(payload)
    response = bedrock.invoke_model(
        body=body,
        modelId="stability.sd3-large-v1:0",
        accept="application/json",
        contentType="application/json"
    )
    response_body = json.loads(response['body'].read().decode('utf-8'))
    if "images" in response_body:
        return base64.b64decode(response_body["images"][0])
    else:
        return None

# Function to create video from images
def create_video(images, music_file):
    if not os.path.exists("output"):
        os.makedirs("output")

    output_path = "output/final_video.mp4"
    width, height = 998, 995
    fps = 0.25
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')

    video_writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    for image_path in images:
        img = Image.open(image_path)
        img = img.resize((width, height))
        img_np = np.array(img)
        img_bgr = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
        video_writer.write(img_bgr)

    video_writer.release()

    audio = AudioSegment.from_mp3(music_file)
    video = cv2.VideoCapture(output_path)
    frame_count = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
    fps_video = video.get(cv2.CAP_PROP_FPS)
    video_duration = frame_count / fps_video
    audio = audio[:int(video_duration * 1000)]

    audio_path = "output/temp_audio.mp3"
    audio.export(audio_path, format="mp3")
    final_output_path = "output/final_video_with_audio.mp4"

    os.system(f'ffmpeg -y -i {output_path} -i {audio_path} -c:v copy -c:a aac -strict experimental {final_output_path}')
    os.remove(audio_path)
    return final_output_path

# Streamlit UI
st.title("AI-Powered Advertisement and Video Generator")

# Step 1: Collect the chatbot response
st.subheader("Step 1: Chatbot Response")
st.markdown('<iframe src="https://app.gpt-trainer.com/widget/42a2d945e0e740539dab9c9217b5d142" '
            'width="100%" height="500px" frameborder="0"></iframe>', unsafe_allow_html=True)
last_response = st.text_input("Paste the last chatbot response here:", "")

# Initialize session state for storing generated images
if "generated_images" not in st.session_state:
    st.session_state["generated_images"] = []

if last_response:
    prompt = f"Write a detailed advertisement prompt for Stability AI referring to: {last_response}, and do not include anything by name STABILITY AI"

    if st.button("Generate Advertisement"):
        # Generate the advertisement prompt
        st.subheader("Generated Advertisement")
        llama_output = invoke_llama(prompt)
        st.write(llama_output)

        # Generate images based on the advertisement prompt
        st.subheader("Generated Images")
        st.session_state["generated_images"] = []  # Clear previous images
        for i in range(3):
            image_data = generate_ad_image(llama_output)
            if image_data:
                temp_path = tempfile.mktemp(suffix=".jpg")
                with open(temp_path, "wb") as f:
                    f.write(image_data)
                st.session_state["generated_images"].append(temp_path)
                st.image(image_data, caption=f"Advertisement Image {i+1}", use_column_width=True)

# Video generation section
if st.session_state["generated_images"]:
    if st.button("Generate Video"):
        # Choose a random audio file for the background music
        audio_files = ["aud1.mp3", "aud2.mp3", "aud3.mp3"]
        selected_audio = random.choice(audio_files)
        st.write(f"Using background music: {selected_audio}")

        # Create the video using the stored images
        video_path = create_video(st.session_state["generated_images"], selected_audio)
        st.video(video_path)

        # Provide a download button for the video
        with open(video_path, "rb") as f:
            st.download_button("Download Video", f, file_name="advertisement_video.mp4", mime="video/mp4")
else:
    st.warning("Please generate advertisement images first before creating a video.")